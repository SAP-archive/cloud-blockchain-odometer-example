// DISCLAIMER:
// THIS SAMPLE CODE MAY BE USED SOLELY AS PART OF THE TEST AND EVALUATION OF THE SAP CLOUD PLATFORM
// BLOCKCHAIN SERVICE (THE “SERVICE”) AND IN ACCORDANCE WITH THE TERMS OF THE AGREEMENT FOR THE SERVICE.
// THIS SAMPLE CODE PROVIDED “AS IS”, WITHOUT ANY WARRANTY, ESCROW, TRAINING, MAINTENANCE, OR SERVICE
// OBLIGATIONS WHATSOEVER ON THE PART OF SAP.

//=================================================================================================
//========================================================================================== IMPORT
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

//=================================================================================================
//============================================================================= BLOCKCHAIN DOCUMENT
// Store only the odometer value (unit: kilmetre) and the organization doing the update. The
// VIN is used key for all updates and NOT stored within the payload. The timestamp for updates
// is retrieved from Hyperledger Fabric transaction timestamp.
type docStruct struct {
	Odometer     uint64 `json:"odometer"`
	Organization string `json:"organization"`
}

// FromJSON Deserial read []byte into document structure
func (doc *docStruct) FromJSON(input []byte) *docStruct {
	json.Unmarshal(input, doc)
	return doc
}

// ToJSON Serialize internal document structure to []byte for writing to blockchain
func (doc *docStruct) ToJSON() []byte {
	jsonDoc, _ := json.Marshal(doc)
	return jsonDoc
}

//=================================================================================================
//================================================================================= RETURN HANDLING

// Success HTTP 2xx with a payload
func Success(rc int32, doc string, payload []byte) peer.Response {
	return peer.Response{
		Status:  rc,
		Message: doc,
		Payload: payload,
	}
}

// Error HTTP 4xx or 5xx with an error message
func Error(rc int32, doc string) peer.Response {
	logger.Errorf("Error %d = %s", rc, doc)
	return peer.Response{
		Status:  rc,
		Message: doc,
	}
}

//=================================================================================================
//====================================================================================== VALIDATION
// Validation: all arguments for a function call is passed as a string array args[]. Validate that
// the number, type and length of the arguments are correct.
//
// The Validate function is called as follow:
// 		validate("chaincode function name", args, T[0], Ta[0], Tb[0], T[1], Ta[1], Tb[1], ...)
// The parameter groups T[i], Ta[i], Tb[i] are used to validate each parameter in sequence in args.
// T[i]describes the type/format for the parameter i and Ta[i] and Tb[i] are type dependent.
//
//		T[i]	Ta[i]		Tb[i]				Comment
//		"%s"	minLength	maxLength			String with min/max length
//		"%u"	minValue	maxValue			Unsigned Integer between min/max (inclusive)
//		"%enum"	max			"enum1 enum2 ..."	Enum (one or upto max) from the space separated list supplied
//												Set max=1 if only one specific value is expected
//
func validate(funcName string, args []string, desc ...interface{}) peer.Response {

	logger.Debugf("Function: %s(%s)", funcName, strings.TrimSpace(strings.Join(args, ",")))

	nrArgs := len(desc) / 3

	if len(args) != nrArgs {
		return Error(http.StatusBadRequest, "Parameter Mismatch")
	}

	for i := 0; i < nrArgs; i++ {
		switch desc[i*3] {

		case "%s":
			var minLen = desc[i*3+1].(int)
			var maxLen = desc[i*3+2].(int)
			if len(args[i]) < minLen || len(args[i]) > maxLen {
				return Error(http.StatusBadRequest, "Parameter Length Error")
			}

		case "%u":
			var min = uint64(desc[i*3+1].(int))
			var max = uint64(desc[i*3+2].(int))
			if i, err := strconv.ParseUint(args[i], 10, 64); err != nil || i < min || i > max {
				return Error(http.StatusBadRequest, "Unsigned Integer Parameter Error")
			}

		case "%enum":
			var maxCount = desc[i*3+1].(int)
			var enums = strings.Fields(desc[i*3+2].(string))
			var values = strings.Fields(args[i])
			found := 0
			for _, v := range values {
				for _, e := range enums {
					if v == e {
						found++
						break
					}
				}
			}
			if found != len(values) || len(values) > maxCount {
				return Error(http.StatusBadRequest, "Enum Validation Error")
			}
		}
	}

	return Success(0, "OK", nil)
}

//=================================================================================================
//======================================================================================= MAIN/INIT

var logger = shim.NewLogger("chaincode")

type odoMeter struct {
}

func main() {
	if err := shim.Start(new(odoMeter)); err != nil {
		fmt.Printf("Main: Error starting chaincode: %s", err)
	}
	logger.SetLevel(shim.LogError)
}

func (cc *odoMeter) Init(stub shim.ChaincodeStubInterface) peer.Response {
	return Success(http.StatusNoContent, "OK", nil)
}

//=================================================================================================
//========================================================================================== INVOKE
func (cc *odoMeter) Invoke(stub shim.ChaincodeStubInterface) peer.Response {

	function, args := stub.GetFunctionAndParameters()

	switch strings.ToLower(function) {
	case "create":
		return create(stub, args)
	case "read":
		return read(stub, args)
	case "update":
		return update(stub, args)
	case "delete":
		return delete(stub, args)
	case "history":
		return history(stub, args)
	default:
		logger.Warningf("Invoke('%s') invalid!", function)
		return Error(http.StatusNotImplemented, "Invalid method! Valid methods are 'create|read|update|delete|history'!")
	}
}

//=================================================================================================
//========================================================================================== CREATE
func create(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	// Validate and extract parameters
	if rc := validate("create", args /*args[0]=vin*/, "%s", 17, 17 /*args[1]=organization*/, "%s", 1, 64); rc.Status > 0 {
		return rc
	}
	vin := strings.ToUpper(args[0])
	doc := &docStruct{Odometer: 0, Organization: args[1]}

	// Validate that this VIN does not yet exist
	if value, err := stub.GetState(vin); !(err == nil && value == nil) {
		return Error(http.StatusConflict, "Already Exists")
	}

	// Write the new VIN
	if err := stub.PutState(vin, doc.ToJSON()); err != nil {
		return Error(http.StatusInternalServerError, err.Error())
	}

	return Success(http.StatusCreated, "Created", nil)
}

//=================================================================================================
//============================================================================================ READ
func read(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	// Validate and extract parameters
	if rc := validate("read", args /*args[0]=vin*/, "%s", 17, 17); rc.Status > 0 {
		return rc
	}
	vin := strings.ToUpper(args[0])

	// Read the value for the VIN
	value, err := stub.GetState(vin)
	if err != nil || value == nil {
		return Error(http.StatusNotFound, "Not Found")
	}
	var doc docStruct
	return Success(http.StatusOK, "OK", []byte(strconv.FormatUint(doc.FromJSON(value).Odometer, 10)))
}

//=================================================================================================
//========================================================================================== UPDATE
func update(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	// Validate and extract parameters
	if rc := validate("update", args /*args[0]=vin*/, "%s", 17, 17 /*args[1]=organization*/, "%s", 1, 64 /*args[2]=odometer*/, "%u", 1, 9999999 /*args[3]=unit*/, "%enum", 1, "kilometre kilometer kilometers km mile miles mi"); rc.Status > 0 {
		return rc
	}
	vin := strings.ToUpper(args[0])
	doc := &docStruct{Odometer: 0, Organization: args[1]}

	// Extract new odometer value and if in miles, convert to kilometre
	doc.Odometer, _ = strconv.ParseUint(args[2], 10, 64)
	if args[3][0:1] == "mi" {
		doc.Odometer = uint64(float64(doc.Odometer) * 1.609344)
	}

	// Validate that this ID exist
	value, err := stub.GetState(vin)
	if err != nil || value == nil {
		return Error(http.StatusNotFound, "Not Found")
	}

	// Validate that NEW OdoMeter exceeds/equal existing value!
	// Equal: could happen if vehicle passes through two different instances witout actually been moved.
	var existingDoc docStruct
	if doc.Odometer < existingDoc.FromJSON(value).Odometer {
		return Error(http.StatusNotAcceptable, "Update Not Acceptable")
	}

	// Write the update
	if err := stub.PutState(vin, doc.ToJSON()); err != nil {
		return Error(http.StatusInternalServerError, err.Error())
	}

	return Success(http.StatusNoContent, "Updated", nil)
}

//=================================================================================================
//========================================================================================== DELETE
func delete(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	// Validate and extract parameters
	if rc := validate("delete", args /*args[0]=vin*/, "%s", 17, 17); rc.Status > 0 {
		return rc
	}
	vin := strings.ToUpper(args[0])

	// Validate that this VIN exist
	if value, err := stub.GetState(vin); err != nil || value == nil {
		return Error(http.StatusNotFound, "Not Found")
	}

	// Delete the VIN
	if err := stub.DelState(vin); err != nil {
		return Error(http.StatusInternalServerError, err.Error())
	}

	return Success(http.StatusNoContent, "Deleted", nil)
}

//=================================================================================================
//========================================================================================= HISTORY
func history(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	// Validate and extract parameters
	if rc := validate("history", args /*args[0]=vin*/, "%s", 17, 17); rc.Status > 0 {
		return rc
	}
	vin := strings.ToUpper(args[0])

	// Read history
	resultsIterator, err := stub.GetHistoryForKey(vin)
	if err != nil {
		return Error(http.StatusNotFound, "Not Found")
	}
	defer resultsIterator.Close()

	// Write return buffer
	var buffer bytes.Buffer
	buffer.WriteString("{\"VIN\":\"")
	buffer.WriteString(vin)
	buffer.WriteString("\", \"history\": [")
	for resultsIterator.HasNext() {
		it, _ := resultsIterator.Next()
		if buffer.Len() > 24+len(vin) {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"timestamp\":\"")
		buffer.WriteString(time.Unix(it.Timestamp.Seconds, int64(it.Timestamp.Nanos)).Format(time.Stamp))
		if !it.IsDelete {
			var doc docStruct
			doc.FromJSON(it.Value)
			buffer.WriteString("\", \"kilometre\":\"")
			buffer.WriteString(strconv.FormatUint(doc.Odometer, 10))
			buffer.WriteString("\", \"organization\":\"")
			buffer.WriteString(doc.Organization)
			buffer.WriteString("\"")
		} else {
			buffer.WriteString("\", \"kilometre\":\"-1\", \"organization\":\"DELETED\"")
		}
		buffer.WriteString("}")
	}
	buffer.WriteString("]}")

	return Success(200, "OK", buffer.Bytes())
}
